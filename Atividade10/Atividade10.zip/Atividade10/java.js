var obj1 = new Object(); //Primeiro modo
	obj1.RA = "001";
	obj1.Nome = "Matheus";
	
alert("Valores obj1 = RA: "+obj1.RA+" - Nome: "+obj1.Nome);


var obj2 = { //Segundo modo
	RA : "002",
	Nome : "Felipo"};

alert("Valores obj2 = RA: "+obj2.RA+" - Nome: "+obj2.Nome);


var obj3 = {}; //Terceiro modo
	obj3["RA"] = "003";
	obj3["Nome"] = "Marina";
	
alert("Valores obj3 = RA: "+obj3.RA+" - Nome: "+obj3.Nome);