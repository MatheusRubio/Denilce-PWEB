function Retangulo(x, y){//Função Retangulo
	this.x = x;
	this.y = y;
	var totalArea = x * y;
	
	this.getArea = function(){
		return totalArea;
	}
}

var ret = new Retangulo(2, 5);

alert ("Area do retangulo: "+ret.getArea());


function Conta(){
	var nomeCom;
	var banco;
	var numeroCon;
	var saldo;
	
	this.setNome = function (nome){nomeCom = nome;}
	this.setBanco = function (nome){banco = nome;}
	this.setNumeroCon = function (num){numeroCon = num;}
	this.setSaldo = function (valor){saldo = valor;}
	
	this.getNome = function(){return nomeCom;}
	this.getBanco = function(){return banco;}
	this.getNumConta = function(){return numeroCon;}
	this.getSaldo = function(){return saldo;}
}

function Corrente(){
	var saldoEsp;
	
	this.setSaldoEsp = function (valor){saldoEsp = valor;}
	
	this.getSaldoEsp = function(){return saldoEsp;}
}
function Poupanca(juros, dataVenc){
	var juros;
	var dataVenc;
	
	this.setJuros = function (valor){juros = valor;}
	this.setDataVenc = function (data){dataVenc = data;}
	
	this.getJuros = function(){return juros;}
	this.getDataVenc = function(){return dataVenc;}	
}
//Herança
Corrente.prototype = new Conta();
Poupanca.prototype = new Conta();

//Criando Object
cCorrente = new Corrente();
cPoupanca = new Poupanca();

//Inserindo valores
cCorrente.setNome("Matheus");
cCorrente.setBanco("Nu");
cCorrente.setNumeroCon("150");
cCorrente.setSaldo(800);
cCorrente.setSaldoEsp(100);

cPoupanca.setNome("Anddressa");
cPoupanca.setBanco("Inter");
cPoupanca.setNumeroCon("123");
cPoupanca.setSaldo(1000);
cPoupanca.setJuros(2);
cPoupanca.setDataVenc("21/10");

alert("Dados da conta Corrente: " +
		"\nNome: "+cCorrente.getNome()+". Banco: "+cCorrente.getBanco()+
		"\nN Conta: "+cCorrente.getNumConta()+". Saldo: "+cCorrente.getSaldo()+". Saldo Especial: "+cCorrente.getSaldoEsp());
		
alert("Dados da conta Poupança: " +
		"\nNome: "+cPoupanca.getNome()+". Banco: "+cPoupanca.getBanco()+
		"\nN Conta: "+cPoupanca.getNumConta()+". Saldo: "+cPoupanca.getSaldo()+". Juros: "+cPoupanca.getJuros()+". Data Venc.: "+cPoupanca.getDataVenc());