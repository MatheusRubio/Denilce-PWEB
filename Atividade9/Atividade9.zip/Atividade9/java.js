var numeros = new Array(3);

for(var i=0; i < numeros.length; i++){
	numeros[i] = prompt("Digite o n de posição "+i+":");
}

var funcMaiorMenor = function(arr){
	return Math.max.apply(null, arr);
}

var funcOrdena = function(arr){
	return arr.sort();
}

alert("O maior número é: "+funcMaiorMenor(numeros) +
		"\nE a array ordenada é: "+funcOrdena(numeros));